Github: https://github.com/neolao/mp3-player
WebSite: http://flash-mp3-player.net/

Helper to support mp3 files if the browser audio element isn't compatible with this file format.