define(function( require )
{
	var UIVersionManager	= require('UI/UIVersionManager');
	var BasicInfoV0 = require('UI/Components/BasicInfo/BasicInfoV0/BasicInfoV0');
	var BasicInfoV3 = require('UI/Components/BasicInfo/BasicInfoV3/BasicInfoV3');
	var BasicInfoV4 = require('UI/Components/BasicInfo/BasicInfoV4/BasicInfoV4');
	var EquipmentV0 = require('UI/Components/Equipment/EquipmentV0/EquipmentV0');
	var EquipmentV1 = require('UI/Components/Equipment/EquipmentV1/EquipmentV1');
	var EquipmentV2 = require('UI/Components/Equipment/EquipmentV2/EquipmentV2');

	return function Init(){
		const defaultSelectionMethod = UIVersionManager.selectUIVersion;
		const customSelectionMethod = function(publicName, versionInfo) {
			if (publicName === 'BasicInfo') {
				versionInfo.common = {1: BasicInfoV0};
			}
			if (publicName === 'Equipment') {
				versionInfo.common = {1: EquipmentV0};
			}
			return defaultSelectionMethod(publicName, versionInfo);
		}
		UIVersionManager.selectUIVersion = customSelectionMethod;
		return true;
	}
});
