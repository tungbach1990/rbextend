# KeyToMove plugin
Enables players to move with keyboard, using the arrow keys.
- Short press moves the character 1 cell
- Holding key will move the player 3 cells (to reduce latency)
## Installing
Please use the main [plugin guide](https://github.com/MrAntares/roBrowserLegacy-plugins#readme)
