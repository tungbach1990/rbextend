define(function (require) {
    'use strict';

    const Log = function (...args) {
        const error = new Error();
        const stack = error.stack.split('\n');
        const callerInfo = stack[2].trim(); // Dòng này chứa thông tin file và số dòng

        console.log(`[${callerInfo}]`, ...args);
    };

    return Log;
});


