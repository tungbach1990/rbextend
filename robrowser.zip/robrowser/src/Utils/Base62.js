define(function (require)
{
    'use strict';

    class Base62 {
        constructor() {
            this.charset = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
        }
        encode(interger) {
            if (interger === 0) {
                return 0;
            }
            let s = [];
            while (interger > 0) {
                s = [this.charset[interger % 62], ...s];
                interger = Math.floor(interger / 62);
            }
            return s.join('');
        }
        decode(chars) {
            return chars.split('').reverse().reduce((prev, curr, i) => prev + (this.charset.indexOf(curr) * (62 ** i)), 0);
        }
    }

    
    return Base62;
});


