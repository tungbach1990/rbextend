/**
 * Engine/MapEngine/Refine.js
 *
 * Manage RefineUI
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 */

define(function (require) {
	'use strict';


	/**
	 * Load dependencies
	 */
	var DB = require('DB/DBManager');
	var Network = require('Network/NetworkManager');
	var PACKET = require('Network/PacketStructure');
	var Session = require('Engine/SessionStorage');
	var ChatBox          = require('UI/Components/ChatBox/ChatBox');
	var BarterShop = require('UI/Components/BarterShop/BarterShop');

	/**
	 * Engine namespace
	 */
	var BarterEngine = {};

	/**
	 * Open Refine and request to server Refine details
	 */
	function onBarterShopOpen(pkt) {
		BarterShop.append();
		BarterShop.setList(pkt.list);
		BarterShop.focus();
	}
	function onBarterShopResult(pkt) {
		if (pkt.result == 0) {
			ChatBox.addText( "Giao dịch thành công", ChatBox.TYPE.INFO, ChatBox.FILTER.PUBLIC_LOG );
			BarterShop.remove();
			var pkt = new PACKET.CZ.NPC_BARTER_MARKET_CLOSE();
			Network.sendPacket(pkt);
		} else {
			ChatBox.addText( "Giao dịch thất bại", ChatBox.TYPE.ERROR, ChatBox.FILTER.PUBLIC_LOG );
		}
	}


	/**
	 * Get Refine update from deposit
	 *
	 * @param {object} pkt - 
	 */

	/**
	 * Initialize
	 */
	BarterEngine.init = function init() {
		Network.hookPacket(PACKET.ZC.NPC_BARTER_MARKET_ITEMINFO, onBarterShopOpen);
		Network.hookPacket(PACKET.ZC.PC_PURCHASE_RESULT, onBarterShopResult);
	};

	/**
	 * Initialize
	 */
	return BarterEngine;
});
