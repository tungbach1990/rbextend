/**
 * Engine/MapEngine/Refine.js
 *
 * Manage RefineUI
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 */

define(function (require) {
	'use strict';


	/**
	 * Load dependencies
	 */
	var DB = require('DB/DBManager');
	var Network = require('Network/NetworkManager');
	var PACKET = require('Network/PacketStructure');
	var Session = require('Engine/SessionStorage');
	var RefineUI = require('UI/Components/RefineUI/RefineUI');

	/**
	 * Engine namespace
	 */
	var RefineEngine = {};

	/**
	 * Open Refine and request to server Refine details
	 */
	function onRefineUIOpen(pkt) {
		RefineUI.append();
		RefineUI.focus();
	}

	function onMaterialList(pkt) {
		if (!pkt) return;
		//console.log(pkt);
		RefineUI.updateMaterialList(pkt);
	}

	/**
	 * Get Refine update from deposit
	 *
	 * @param {object} pkt - PACKET.ZC.ACK_BANKING_DEPOSIT
	 */

	/**
	 * Initialize
	 */
	RefineEngine.init = function init() {
		Network.hookPacket(PACKET.ZC.OPEN_REFINING_UI, onRefineUIOpen);
		Network.hookPacket(PACKET.ZC.REFINING_MATERIAL_LIST, onMaterialList);
		//Network.hookPacket( PACKET.ZC.BANKING_CHECK, 			  onBankInfo );
		//Network.hookPacket( PACKET.ZC.ACK_BANKING_DEPOSIT,		  onBankDepoUpdate );
		//Network.hookPacket( PACKET.ZC.ACK_BANKING_WITHDRAW,		  onBankWithdrawUpdate );
		//Network.hookPacket( PACKET.ZC.ACK_CLOSE_BANKING,		  onBankClose );
	};

	/**
	 * Initialize
	 */
	return RefineEngine;
});
