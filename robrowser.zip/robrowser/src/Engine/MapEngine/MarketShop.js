/**
 * Engine/MapEngine/Refine.js
 *
 * Manage RefineUI
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 */

define(function (require) {
	'use strict';


	/**
	 * Load dependencies
	 */
	var DB = require('DB/DBManager');
	var Network = require('Network/NetworkManager');
	var PACKET = require('Network/PacketStructure');
	var Session = require('Engine/SessionStorage');
	var ChatBox          = require('UI/Components/ChatBox/ChatBox');
	var MarketShop = require('UI/Components/MarketShop/MarketShop');

	/**
	 * Engine namespace
	 */
	var RefineEngine = {};

	/**
	 * Open Refine and request to server Refine details
	 */
	function onMarketShopOpen(pkt) {
		MarketShop.append();
		MarketShop.setList(pkt.list);
		MarketShop.focus();
	}
	function onMarketShopResult(pkt) {
		if (pkt.result == 0) {
			ChatBox.addText( "Giao dịch thành công", ChatBox.TYPE.INFO, ChatBox.FILTER.PUBLIC_LOG );
			MarketShop.remove();
			var pkt = new PACKET.CZ.NPC_MARKET_CLOSE();
			Network.sendPacket(pkt);
		} else {
			ChatBox.addText( "Giao dịch thất bại", ChatBox.TYPE.ERROR, ChatBox.FILTER.PUBLIC_LOG );
		}
	}


	/**
	 * Get Refine update from deposit
	 *
	 * @param {object} pkt - 
	 */

	/**
	 * Initialize
	 */
	RefineEngine.init = function init() {
		Network.hookPacket(PACKET.ZC.NPC_MARKET_OPEN, onMarketShopOpen);
		Network.hookPacket(PACKET.ZC.NPC_MARKET_PURCHASE_RESULT, onMarketShopResult);
	};

	/**
	 * Initialize
	 */
	return RefineEngine;
});
