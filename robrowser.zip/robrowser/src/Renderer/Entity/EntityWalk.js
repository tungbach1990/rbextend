/**
 * Renderer/EntityWalk.js
 *
 * Manage entity walking action
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 *
 * @author Vincent Thibault
 */
<<<<<<< HEAD
define( function( require )
{
=======
define(function (require) {
>>>>>>> 37b81d87e (init robrowser)
	'use strict';

	/**
	 *  Load dependencies
	 */
	var PathFinding = require('Utils/PathFinding');
<<<<<<< HEAD
	var Renderer    = require('Renderer/Renderer');
	var Altitude    = require('Renderer/Map/Altitude');
=======
	var Renderer = require('Renderer/Renderer');
	var Altitude = require('Renderer/Map/Altitude');
>>>>>>> 37b81d87e (init robrowser)

	/**
	 * Direction look up table
	 */
	var DIRECTION = [
<<<<<<< HEAD
		[1,2,3],
		[0,0,4],
		[7,6,5]
=======
		[1, 2, 3],
		[0, 0, 4],
		[7, 6, 5]
>>>>>>> 37b81d87e (init robrowser)
	];


	/**
	 * Walk save structure
	 */
<<<<<<< HEAD
	function WalkStructure()
	{
		this.speed =  150;
		this.tick  =  0;
		this.prevTick = 0;
		this.path  =  new Int16Array(PathFinding.MAX_WALKPATH * 2);
		this.pos   =  new Float32Array(3);
		this.onEnd = null;
		this.index =  0;
		this.total =  0;
=======
	function WalkStructure() {
		this.speed = 150;
		this.tick = 0;
		this.prevTick = 0;
		this.path = new Int16Array(PathFinding.MAX_WALKPATH * 2);
		this.pos = new Float32Array(3);
		this.onEnd = null;
		this.state = null;
		this.index = 0;
		this.total = 0;
>>>>>>> 37b81d87e (init robrowser)
	}

	/**
	 * Want to move non walkable cell
	 *
	 * @param {number} from_x
	 * @param {number} from_y
	 * @param {number} to_x
	 * @param {number} to_y
	 * @param {number} range optional
	 * @param {bool} isOverShoot use for falcon
	 * @param {bool} isAttacking falcon = set walk / wug = set attack
	 */
<<<<<<< HEAD
	function walkToNonWalkableGround( from_x, from_y, to_x, to_y, range, isOverShoot = false, isAttacking = false )
	{
=======
	function walkToNonWalkableGround(from_x, from_y, to_x, to_y, range, isOverShoot = false, isAttacking = false) {
>>>>>>> 37b81d87e (init robrowser)
		this.resetRoute();

		this.isAttacking = isAttacking;

		// calculate overshoot (only falcon)
		if (this.objecttype === this.constructor.TYPE_FALCON && isOverShoot) {
			var OverShootPosition = calculateOverShot(from_x, from_y, to_x, to_y);
			to_x = OverShootPosition[0];
			to_y = OverShootPosition[1];
		}

		// Same position
<<<<<<< HEAD
		if(from_x === to_x && from_y === to_y) {
			return;
		}

		var path  = this.walk.path;
		var total = 0;
		var result = PathFinding.searchLongIgnoreCellType( from_x | 0, from_y | 0, to_x | 0, to_y | 0, range || 0, path, true);

		if(result.success)
			total = result.pathLength + 1

		this.walk.index =     1 * 2; // skip first index
		this.walk.total = total * 2;
		if (total > 0) {
			this.walk.pos.set(this.position);
			this.walk.tick =  this.walk.prevTick = Renderer.tick;
=======
		if (from_x === to_x && from_y === to_y) {
			return;
		}

		var path = this.walk.path;
		var total = 0;
		var result = PathFinding.searchLongIgnoreCellType(from_x | 0, from_y | 0, to_x | 0, to_y | 0, range || 0, path, true);

		if (result.success)
			total = result.pathLength + 1

		this.walk.index = 1 * 2; // skip first index
		this.walk.total = total * 2;
		if (total > 0) {
			this.walk.pos.set(this.position);
			this.walk.tick = this.walk.prevTick = Renderer.tick;
>>>>>>> 37b81d87e (init robrowser)

			var action = this.ACTION.WALK;
			if (this.objecttype === this.constructor.TYPE_FALCON && !isAttacking) // falcon: action.walk = gliding
				action = this.ACTION.IDLE;
			if (this.objecttype === this.constructor.TYPE_WUG && isAttacking)
				action = this.ACTION.ATTACK;

<<<<<<< HEAD
			if(this.action !== action) {
				this.setAction({
					action: action,
					frame:  0,
					repeat: true,
					play:   true
=======
			if (this.action !== action) {
				this.setAction({
					action: action,
					frame: 0,
					repeat: true,
					play: true
>>>>>>> 37b81d87e (init robrowser)
				});
			}
		}
	}

	/**
	 * Want to move to a cell
	 *
	 * @param {number} from_x
	 * @param {number} from_y
	 * @param {number} to_x
	 * @param {number} to_y
	 * @param {number} range optional
	 */
<<<<<<< HEAD
	function walkTo( from_x, from_y, to_x, to_y, range )
	{
		this.resetRoute();

		// Same position
		if(from_x === to_x && from_y === to_y) {
			return;
		}

		var path  = this.walk.path;
		
		var total = PathFinding.search( from_x | 0, from_y | 0, to_x | 0, to_y | 0, range || 0, path);

		this.walk.index =     1 * 2; // skip first index
=======
	function walkTo(from_x, from_y, to_x, to_y, range) {
		this.resetRoute();

		// Same position
		if (from_x === to_x && from_y === to_y) {
			return;
		}

		var path = this.walk.path;

		var total = PathFinding.search(from_x | 0, from_y | 0, to_x | 0, to_y | 0, range || 0, path);

		this.walk.index = 1 * 2; // skip first index
>>>>>>> 37b81d87e (init robrowser)
		this.walk.total = total * 2;

		if (total) {
			this.walk.pos.set(this.position);
<<<<<<< HEAD
			this.walk.tick =  this.walk.prevTick = Renderer.tick;
			this.headDir   = 0;

			this.setAction({
				action: this.ACTION.WALK,
				frame:  0,
				repeat: true,
				play:   true
=======
			this.walk.tick = this.walk.prevTick = Renderer.tick;
			this.headDir = 0;

			this.setAction({
				action: this.ACTION.WALK,
				frame: 0,
				repeat: true,
				play: true
>>>>>>> 37b81d87e (init robrowser)
			});
		}
	}

	/**
	 * Process walking
	 */
<<<<<<< HEAD
	function walkProcess()
	{
		var pos  = this.position;
=======

	function walkProcess() {
		var pos = this.position;
>>>>>>> 37b81d87e (init robrowser)
		var walk = this.walk;
		var path = walk.path;
		var index = walk.index;
		var total = walk.total;

		var x, y, speed;
		var TICK = Renderer.tick;
		var delay = 0;
		var cellHeight;
		var falconGliding = 5;

<<<<<<< HEAD
		if(total == 0)
			return;

		if (this.action === this.ACTION.WALK || this.objecttype === this.constructor.TYPE_FALCON || this.objecttype === this.constructor.TYPE_WUG) {

			if (index < total) {
				
				// Calculate new position, base on time and walk speed.
				while (index < total) {
					x = path[index+0] - (walk.pos[0]);
					y = path[index+1] - (walk.pos[1]);

					// Seems like walking on diagonal is slower ?
					speed = ( x && y ) ? walk.speed / 0.7 : walk.speed;

=======
		if (total == 0) {

			/// prevSpeedFastMove được set thêm khi FASTMOVE
			/// Chữa cháy cách trước mắt, nếu speed đang là 10 của FASTMOVE, và có giá trị prevSpeedFastMove thì set lại speed
			if (this.walk.prevSpeedFastMove && this.walk.speed == 10) {
				this.onWalkEnd();
				this.walk.speed = this.walk.prevSpeedFastMove;
				this.walk.prevSpeedFastMove = null;
				if (this.walk.onEnd) {
					this.walk.onEnd();
					this.walk.onEnd = null;
				}
			}
			
			/// Thử kiểm tra onWalkEnd hoặc walk.onEnd	
			if (walk.onEnd) {
				walk.onEnd();
				walk.onEnd = null;
			}

			return;
		} else {
		}

		if (this.action === this.ACTION.WALK || this.objecttype === this.constructor.TYPE_FALCON || this.objecttype === this.constructor.TYPE_WUG) {
			if (index < total) {
				// Calculate new position, base on time and walk speed.
				while (index < total) {
					x = path[index + 0] - (walk.pos[0]);
					y = path[index + 1] - (walk.pos[1]);
					
					// Seems like walking on diagonal is slower ?
					speed = (x && y) ? walk.speed / 0.7 : walk.speed;
					
>>>>>>> 37b81d87e (init robrowser)
					// New position :)
					if (TICK - walk.tick <= speed) {
						break;
					}

					walk.tick += speed;
					walk.prevTick = TICK; // Store tick

<<<<<<< HEAD
					walk.pos[0] = path[index+0];
					walk.pos[1] = path[index+1];
					index += 2;
				}

				// Calculate and store new position
				// TODO: check the min() part.

				delay      = Math.min(speed, TICK-walk.tick);
				walk.index = index;

=======
					walk.pos[0] = path[index + 0];
					walk.pos[1] = path[index + 1];
					index += 2;
				}
				
				// Calculate and store new position
				// TODO: check the min() part.
				
				delay = Math.min(speed, TICK - walk.tick);
				walk.index = index;
				
>>>>>>> 37b81d87e (init robrowser)
				// Should not happened, avoid division by 0
				if (!delay) {
					delay = 150;
				}
<<<<<<< HEAD

				cellHeight = this.objecttype == this.constructor.TYPE_FALCON ? Altitude.getCellHeight( pos[0], pos[1] ) + falconGliding : Altitude.getCellHeight( pos[0], pos[1] );
=======
				
				cellHeight = this.objecttype == this.constructor.TYPE_FALCON ? Altitude.getCellHeight(pos[0], pos[1]) + falconGliding : Altitude.getCellHeight(pos[0], pos[1]);
>>>>>>> 37b81d87e (init robrowser)
				pos[0] = walk.pos[0] + x / (speed / delay);
				pos[1] = walk.pos[1] + y / (speed / delay);
				pos[2] = cellHeight;

				// Update player direction while walking
				if (index < total) {
<<<<<<< HEAD
					this.direction = DIRECTION[(x>0?1:x<0?-1:0)+1][(y>0?1:y<0?-1:0)+1];
=======
					this.direction = DIRECTION[(x > 0 ? 1 : x < 0 ? -1 : 0) + 1][(y > 0 ? 1 : y < 0 ? -1 : 0) + 1];
>>>>>>> 37b81d87e (init robrowser)
					return;
				}
			}

			// Stop walking
<<<<<<< HEAD
			if(this.objecttype == this.constructor.TYPE_WUG && this.isAttacking) {
				this.setAction({
					action: this.ACTION.ATTACK,
					frame:  0,
					repeat: false,
					play:   true,
					next: {
						delay:  Renderer.tick + 432,
						action: this.ACTION.IDLE,
						frame:  0,
						repeat: false,
						play:   true,
						next:  false
=======
			if (this.objecttype == this.constructor.TYPE_WUG && this.isAttacking) {
				this.setAction({
					action: this.ACTION.ATTACK,
					frame: 0,
					repeat: false,
					play: true,
					next: {
						delay: Renderer.tick + 432,
						action: this.ACTION.IDLE,
						frame: 0,
						repeat: false,
						play: true,
						next: false
>>>>>>> 37b81d87e (init robrowser)
					}
				});
			} else {
				this.setAction({
					action: this.ACTION.IDLE,
<<<<<<< HEAD
					frame:  0,
					play:   true,
=======
					frame: 0,
					play: true,
>>>>>>> 37b81d87e (init robrowser)
					repeat: true
				});
			}

			this.onWalkEnd();

<<<<<<< HEAD
			// Temporary callback
=======
>>>>>>> 37b81d87e (init robrowser)
			if (walk.onEnd) {
				walk.onEnd();
				walk.onEnd = null;
			}
<<<<<<< HEAD
			cellHeight = this.objecttype == this.constructor.TYPE_FALCON ? Altitude.getCellHeight( pos[0], pos[1] ) + 5 : Altitude.getCellHeight( pos[0], pos[1] );
=======

			cellHeight = this.objecttype == this.constructor.TYPE_FALCON ? Altitude.getCellHeight(pos[0], pos[1]) + 5 : Altitude.getCellHeight(pos[0], pos[1]);
>>>>>>> 37b81d87e (init robrowser)
			pos[0] = Math.round(pos[0]);
			pos[1] = Math.round(pos[1]);
			pos[2] = cellHeight;
			this.resetRoute();
			this.isAttacking = false;
<<<<<<< HEAD
		} 
=======
		}
>>>>>>> 37b81d87e (init robrowser)
		else {
			if (index < total) { // Walking got interrupted by getting attacked or other means
				this.walk.tick += TICK - this.walk.prevTick; // Offset walking by the time elapsed.
				this.walk.prevTick = TICK; // Store tick
<<<<<<< HEAD
=======

				this.walk.state = "STOP.MOVING.UNWANTED";
				
				//debugger;
				this.onWalkEnd();
				
				// Temporary callback
				if (walk.onEnd) {
					walk.onEnd();
					walk.onEnd = null;
				}
			} else {
>>>>>>> 37b81d87e (init robrowser)
			}
			return;
		}
	}

	function entitiesWalkProcess() {
<<<<<<< HEAD
		var player_entity;

		if(this.walk.lastWalkTick + 200 > Renderer.tick) {
			return;
		}

		if(this.falcon) {
			player_entity = this.falcon;
		} else if(this.wug) {
			player_entity = this.wug;
		}

		if(player_entity) {
			if(player_entity.isAttacking)
				return;

			let range = player_entity.objecttype == player_entity.constructor.TYPE_FALCON ? 1 : 4;
			let distance = Math.floor(this.distance(this,player_entity));

			if(player_entity.objecttype == player_entity.constructor.TYPE_FALCON) {
				if(distance > 5)
=======
		/////////////////////////////////////////////////
		//Tại sao gọi hàm này liên tục dù đang đứng yên, thay vì ACTION.IDLE ???
		var player_entity;

		if (this.walk.lastWalkTick + 200 > Renderer.tick) {
			/////////////////////////////////////////////////
			// Gọi hàm entitiesWalkProcess() liên tục trong loop, nhưng lại ngắt ở đây khi entity đứng im
			return;
		}

		if (this.falcon) {
			player_entity = this.falcon;
		} else if (this.wug) {
			player_entity = this.wug;
		}

		if (player_entity) {
			if (player_entity.isAttacking) {
				return;
			}

			let range = player_entity.objecttype == player_entity.constructor.TYPE_FALCON ? 1 : 4;
			let distance = Math.floor(this.distance(this, player_entity));

			if (player_entity.objecttype == player_entity.constructor.TYPE_FALCON) {
				if (distance > 5)
>>>>>>> 37b81d87e (init robrowser)
					player_entity.walk.speed = this.walk.speed - 10;
				else
					player_entity.walk.speed = this.walk.speed + 5;
			} else {
				player_entity.walk.speed = this.walk.speed - 10;
			}

<<<<<<< HEAD
			if(distance >= range && (player_entity.walk.total == 0 || player_entity.walk.total - player_entity.walk.index <= 2)) { // 2 = last steps
				if(this.walk.total)
					player_entity.walkToNonWalkableGround( player_entity.position[0], player_entity.position[1], this.walk.path[this.walk.total-2], this.walk.path[this.walk.total-1], range-1, false, false); // wug always stay 3 cells away from owner
				else
					player_entity.walkToNonWalkableGround( player_entity.position[0], player_entity.position[1], Math.round(this.position[0]), Math.round(this.position[1]), range-1, false, false); // wug always stay 3 cells away from owner
=======
			if (distance >= range && (player_entity.walk.total == 0 || player_entity.walk.total - player_entity.walk.index <= 2)) { // 2 = last steps
				if (this.walk.total)
					player_entity.walkToNonWalkableGround(player_entity.position[0], player_entity.position[1], this.walk.path[this.walk.total - 2], this.walk.path[this.walk.total - 1], range - 1, false, false); // wug always stay 3 cells away from owner
				else
					player_entity.walkToNonWalkableGround(player_entity.position[0], player_entity.position[1], Math.round(this.position[0]), Math.round(this.position[1]), range - 1, false, false); // wug always stay 3 cells away from owner
>>>>>>> 37b81d87e (init robrowser)
			}
		}
		this.walk.lastWalkTick = Renderer.tick;
	}

<<<<<<< HEAD
	function resetRoute() {
		this.walk.tick  =  0;
		this.walk.prevTick = 0;
		this.walk.path  =  new Int16Array(PathFinding.MAX_WALKPATH * 2);
		this.walk.onEnd = null;
		this.walk.index =  0;
		this.walk.total =  0;
=======
	/*    
	function walkProcess() {
		var pos = this.position;
		var walk = this.walk;
		var path = walk.path;
		var index = walk.index;
		var total = walk.total;
	
		var x, y, speed;
		var TICK = Renderer.tick;
		var delay = 0;
		var cellHeight;
		var falconGliding = 5;
	
		if (total == 0)
			return;
	
		if (this.action === this.ACTION.WALK || this.objecttype === this.constructor.TYPE_FALCON || this.objecttype === this.constructor.TYPE_WUG) {
	
			if (index < total) {
	
				// Determine speed based on current state (normal or fast moving)
				speed = this.isFastMoving ? 10 : walk.speed;
	
				// Calculate new position based on time and walk speed.
				while (index < total) {
					x = path[index] - walk.pos[0];
					y = path[index + 1] - walk.pos[1];
	
					// New position :)
					if (TICK - walk.tick <= speed) {
						break;
					}
	
					walk.tick += speed;
	
					walk.pos[0] = path[index];
					walk.pos[1] = path[index + 1];
					index += 2;
				}
	
				// Calculate and store new position
				delay = Math.min(speed, TICK - walk.tick);
				walk.index = index;
	
				// Should not happen, avoid division by 0
				if (!delay) {
					delay = 150;
				}
	
				// Adjust cell height for falcon
				cellHeight = this.objecttype === this.constructor.TYPE_FALCON ? Altitude.getCellHeight(pos[0], pos[1]) + falconGliding : Altitude.getCellHeight(pos[0], pos[1]);
	
				// Update position
				pos[0] = walk.pos[0] + x / (speed / delay);
				pos[1] = walk.pos[1] + y / (speed / delay);
				pos[2] = cellHeight;
	
				// Update player direction while walking
				if (index < total) {
					this.direction = DIRECTION[(x > 0 ? 1 : x < 0 ? -1 : 0) + 1][(y > 0 ? 1 : y < 0 ? -1 : 0) + 1];
					return;
				}
			}
	
			// Stop walking
			if (this.objecttype === this.constructor.TYPE_WUG && this.isAttacking) {
				this.setAction({
					action: this.ACTION.ATTACK,
					frame: 0,
					repeat: false,
					play: true,
					next: {
						delay: Renderer.tick + 432,
						action: this.ACTION.IDLE,
						frame: 0,
						repeat: false,
						play: true,
						next: false
					}
				});
			} else {
				this.setAction({
					action: this.ACTION.IDLE,
					frame: 0,
					play: true,
					repeat: true
				});
			}
	
			this.onWalkEnd();
	
			// Temporary callback
			if (walk.onEnd) {
				walk.onEnd();
				walk.onEnd = null;
			}
	
			// Reset position and route
			cellHeight = this.objecttype === this.constructor.TYPE_FALCON ? Altitude.getCellHeight(pos[0], pos[1]) + 5 : Altitude.getCellHeight(pos[0], pos[1]);
			pos[0] = Math.round(pos[0]);
			pos[1] = Math.round(pos[1]);
			pos[2] = cellHeight;
			this.resetRoute();
			this.isAttacking = false;
		} else {
			// If interrupted, adjust tick and handle accordingly
			if (index < total) {
				this.walk.tick += TICK - this.walk.prevTick; // Offset walking by elapsed time.
				this.walk.prevTick = TICK; // Store tick
			}
			return;
		}
	}
	
	
	function entitiesWalkProcess() {
		var player_entity;
	
		// Throttle walk updates
		if (this.walk.lastWalkTick + 200 > Renderer.tick) {
			return;
		}
	
		// Determine player entity (falcon or wug)
		if (this.falcon) {
			player_entity = this.falcon;
		} else if (this.wug) {
			player_entity = this.wug;
		}
	
		// Process if player entity exists
		if (player_entity) {
			if (player_entity.isAttacking) {
				return;
			}
	
			let range = player_entity.objecttype === player_entity.constructor.TYPE_FALCON ? 1 : 4;
			let distance = Math.floor(this.distance(this, player_entity));
	
			// Adjust speed based on distance and entity type
			if (player_entity.objecttype === player_entity.constructor.TYPE_FALCON) {
				if (distance > 5) {
					player_entity.walk.speed = this.walk.speed - 10;
				} else {
					player_entity.walk.speed = this.walk.speed + 5;
				}
			} else {
				player_entity.walk.speed = this.walk.speed - 10;
			}
	
			// Perform fast move if conditions are met
			if (distance >= range && (player_entity.walk.total === 0 || player_entity.walk.total - player_entity.walk.index <= 2)) {
				// Decide where to move based on the current state
				if (this.walk.total) {
					player_entity.walkToNonWalkableGround(player_entity.position[0], player_entity.position[1], this.walk.path[this.walk.total - 2], this.walk.path[this.walk.total - 1], range - 1, false, false); // wug always stay 3 cells away from owner
				} else {
					player_entity.walkToNonWalkableGround(player_entity.position[0], player_entity.position[1], Math.round(this.position[0]), Math.round(this.position[1]), range - 1, false, false); // wug always stay 3 cells away from owner
				}
			}
		}
	
		// Update last walk tick for throttling
		this.walk.lastWalkTick = Renderer.tick;
	}
	*/

	function resetRoute() {
		this.walk.tick = 0;
		this.walk.prevTick = 0;
		this.walk.path = new Int16Array(PathFinding.MAX_WALKPATH * 2);
		this.walk.onEnd = null;
		this.walk.state = null;
		this.walk.index = 0;
		this.walk.total = 0;
>>>>>>> 37b81d87e (init robrowser)
	}

	function calculateOverShot(from_x, from_y, to_x, to_y) {
		var overshot = 5;
		var over_x = to_x, over_y = to_y;
		if (from_x > to_x && from_y > to_y) { //Quadrant 3
			over_x = to_x - overshot;
			over_y = to_y - overshot;
		} else if (from_x < to_x && from_y > to_y) { //Quadrant 4
			over_x = to_x + overshot;
			over_y = to_y - overshot;
		} else if (from_x < to_x && from_y < to_y) { //Quadrant 1
			over_x = to_x + overshot;
			over_y = to_y + overshot;
		} else if (from_x > to_x && from_y < to_y) { //Quadrant 2
			over_x = to_x - overshot;
			over_y = to_y + overshot;
		} else if (from_y < to_y) { // pure positve y position
			over_x = to_x;
			over_y = to_y + overshot;
		} else if (to_y < from_y) { // pure negative y position
			over_x = to_x;
			over_y = to_y - overshot;
		} else if (from_x < to_x) { // pure positve y position
			over_x = to_x + overshot;
			over_y = to_y;
		} else if (from_x > to_x) { // pure negative x position
			over_x = to_x - overshot;
			over_y = to_y;
		}
		return [over_x, over_y];
	}

	function distance(entity1, entity2) {
		const x1 = entity1.position[0];
		const y1 = entity1.position[1];
		const x2 = entity2.position[0];
		const y2 = entity2.position[1];
		return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
	}

	/**
	 * Initialize and export methods
	 */
<<<<<<< HEAD
	return function Init()
	{
		this.onWalkEnd   = function onWalkEnd() {};
		this.walk        = new WalkStructure();
		this.walkTo      = walkTo;
=======
	return function Init() {
		this.onWalkEnd = function onWalkEnd() { };
		this.onWalkHit = function onWalkHit() { };
		this.walk = new WalkStructure();
		this.walkTo = walkTo;
>>>>>>> 37b81d87e (init robrowser)
		this.walkToNonWalkableGround = walkToNonWalkableGround;
		this.walkProcess = walkProcess;
		this.entitiesWalkProcess = entitiesWalkProcess;
		this.resetRoute = resetRoute;
		this.distance = distance;
	};
<<<<<<< HEAD
});
=======
});
>>>>>>> 37b81d87e (init robrowser)
