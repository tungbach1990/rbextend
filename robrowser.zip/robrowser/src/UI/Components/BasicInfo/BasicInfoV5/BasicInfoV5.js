/**
 * UI/Components/BasicInfoV5/BasicInfoV5.js
 *
 * Chararacter Basic information windows
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 *
 * @author Vincent Thibault
 */
<<<<<<< HEAD
define(function(require)
{
=======
define(function (require) {
>>>>>>> 37b81d87e (init robrowser)
	'use strict';


	/**
	 * Dependencies
	 */
<<<<<<< HEAD
	var DB                 = require('DB/DBManager');
	var Configs            = require('Core/Configs');
	var PACKETVER          = require('Network/PacketVerManager');
	var MonsterTable       = require('DB/Monsters/MonsterTable');
	var Client             = require('Core/Client');
	var Preferences        = require('Core/Preferences');
	var Renderer           = require('Renderer/Renderer');
	var Session            = require('Engine/SessionStorage');
	var UIManager          = require('UI/UIManager');
	var UIComponent        = require('UI/UIComponent');
	var Inventory          = require('UI/Components/Inventory/Inventory');
	var Equipment          = require('UI/Components/Equipment/Equipment');
	var PartyFriends       = require('UI/Components/PartyFriends/PartyFriends');
	var Guild              = require('UI/Components/Guild/Guild');
	var Bank               = require('UI/Components/Bank/Bank');
	var Escape             = require('UI/Components/Escape/Escape');
	var WorldMap           = require('UI/Components/WorldMap/WorldMap');
	var CheckAttendance    = require('UI/Components/CheckAttendance/CheckAttendance');
	var Rodex              = require('UI/Components/Rodex/Rodex');
	var WinStats           = require('UI/Components/WinStats/WinStats');

	// Version Dependent UIs
	var SkillList = require('UI/Components/SkillList/SkillList');
	var Quest     = require('UI/Components/Quest/Quest');


	var htmlText           = require('text!./BasicInfoV5.html');
	var cssText            = require('text!./BasicInfoV5.css');
=======
	var DB = require('DB/DBManager');
	var Configs = require('Core/Configs');
	var PACKETVER = require('Network/PacketVerManager');
	var MonsterTable = require('DB/Monsters/MonsterTable');
	var Client = require('Core/Client');
	var Preferences = require('Core/Preferences');
	var Renderer = require('Renderer/Renderer');
	var Session = require('Engine/SessionStorage');
	var UIManager = require('UI/UIManager');
	var UIComponent = require('UI/UIComponent');
	var Inventory = require('UI/Components/Inventory/Inventory');
	var Equipment = require('UI/Components/Equipment/Equipment');
	var PartyFriends = require('UI/Components/PartyFriends/PartyFriends');
	var Guild = require('UI/Components/Guild/Guild');
	var Bank = require('UI/Components/Bank/Bank');
	var CashShop = require('UI/Components/CashShop/CashShop');
	var Escape = require('UI/Components/Escape/Escape');
	var WorldMap = require('UI/Components/WorldMap/WorldMap');
	var CheckAttendance = require('UI/Components/CheckAttendance/CheckAttendance');
	var Rodex = require('UI/Components/Rodex/Rodex');
	var WinStats = require('UI/Components/WinStats/WinStats');

	// Version Dependent UIs
	var SkillList = require('UI/Components/SkillList/SkillList');
	var Quest = require('UI/Components/Quest/Quest');


	var htmlText = require('text!./BasicInfoV5.html');
	var cssText = require('text!./BasicInfoV5.css');
>>>>>>> 37b81d87e (init robrowser)

	/**
	 * Create Basic Info component
	 */
<<<<<<< HEAD
	var BasicInfoV5 = new UIComponent( 'BasicInfoV5', htmlText, cssText );
=======
	var BasicInfoV5 = new UIComponent('BasicInfoV5', htmlText, cssText);
>>>>>>> 37b81d87e (init robrowser)


	/**
	 * Stored data
	 */
<<<<<<< HEAD
	BasicInfoV5.base_exp      = 0;
	BasicInfoV5.base_exp_next = 1;
	BasicInfoV5.job_exp       = 0;
	BasicInfoV5.job_exp_next  =-1;
	BasicInfoV5.weight        = 0;
	BasicInfoV5.weight_max    = 1;
=======
	BasicInfoV5.base_exp = 0;
	BasicInfoV5.base_exp_next = 1;
	BasicInfoV5.job_exp = 0;
	BasicInfoV5.job_exp_next = -1;
	BasicInfoV5.weight = 0;
	BasicInfoV5.weight_max = 1;
>>>>>>> 37b81d87e (init robrowser)


	/**
	 * @var {Preferences} structure
	 */
	var _preferences = Preferences.get('BasicInfoV5', {
<<<<<<< HEAD
		x:        0,
		y:        0,
		reduce:   true,
		buttons:  true,
=======
		x: 0,
		y: 0,
		reduce: true,
		buttons: true,
>>>>>>> 37b81d87e (init robrowser)
		magnet_top: true,
		magnet_bottom: false,
		magnet_left: true,
		magnet_right: false
	}, 1.0);


	/**
	 * Initialize UI
	 */
<<<<<<< HEAD
	BasicInfoV5.init = function init()
	{
		// Don't activate drag drop when clicking on buttons
		this.ui.find('.topbar div').mousedown(function( event ){
=======
	BasicInfoV5.init = function init() {
		// Don't activate drag drop when clicking on buttons
		this.ui.find('.topbar div').mousedown(function (event) {
>>>>>>> 37b81d87e (init robrowser)
			event.stopImmediatePropagation();
		});

		this.ui.find('.topbar .right').click(BasicInfoV5.toggleMode.bind(this));
<<<<<<< HEAD
		this.ui.find('.toggle_btns').click(BasicInfoV5.toggleButtons.bind(this));

		this.ui.find('.buttons div').click(function(){
			switch (this.id) {
				case 'item':
					Inventory.getUI().toggle();
=======
		this.ui.find('.toggle_btns').mousedown(BasicInfoV5.toggleButtons.bind(this));

		this.ui.find('.buttons div').mousedown(function () {
			switch (this.id) {
				case 'item':
					Inventory.ui.toggle();
>>>>>>> 37b81d87e (init robrowser)
					break;

				case 'info':
					WinStats.getUI().toggle();
					break;

				case 'equip':
					Equipment.getUI().toggle();
					break;

				case 'skill':
					SkillList.getUI().toggle();
					break;

				case 'option':
					Escape.ui.toggle();
					break;

				case 'party':
					PartyFriends.toggle();
					break;

				case 'guild':
					Guild.toggle();
					break;

				case 'quest':
					Quest.getUI().toggle();
					break;

				case 'map':
					WorldMap.toggle();
					break;

				case 'bank':
					Bank.toggle();
					break;

				case 'attendance':
<<<<<<< HEAD
					if(Configs.get('enableCheckAttendance') && PACKETVER.value >= 20180307) {
=======
					if (Configs.get('enableCheckAttendance') && PACKETVER.value >= 20180307) {
>>>>>>> 37b81d87e (init robrowser)
						CheckAttendance.toggle();
					}
					break;
				case 'mail':
					Rodex.toggle();
					break;
<<<<<<< HEAD
=======
				case 'cashshop':
					if (Consigs.get('enableCashShop')) {
						CashShop.toggle();
					}
					break;
>>>>>>> 37b81d87e (init robrowser)
			}
		});

		this.draggable();
	};


	/**
	 * When append the element to html
	 * Execute elements in memory
	 */
<<<<<<< HEAD
	BasicInfoV5.onAppend = function onAppend()
	{
		// Apply preferences
		this.ui.css({
			top:  Math.min( Math.max( 0, _preferences.y), Renderer.height - this.ui.height()),
			left: Math.min( Math.max( 0, _preferences.x), Renderer.width  - this.ui.width())
=======
	BasicInfoV5.onAppend = function onAppend() {
		// Apply preferences
		this.ui.css({
			top: Math.min(Math.max(0, _preferences.y), Renderer.height - this.ui.height()),
			left: Math.min(Math.max(0, _preferences.x), Renderer.width - this.ui.width())
>>>>>>> 37b81d87e (init robrowser)
		});

		this.magnet.TOP = _preferences.magnet_top;
		this.magnet.BOTTOM = _preferences.magnet_bottom;
		this.magnet.LEFT = _preferences.magnet_left;
		this.magnet.RIGHT = _preferences.magnet_right;

		// large/small window
		this.ui.removeClass('small large');
		if (_preferences.reduce) {
			this.ui.addClass('small');
		}
		else {
			this.ui.addClass('large');
		}

		if (_preferences.buttons) {
			this.ui.find('.buttons').show();
			this.ui.find('.btn_open').hide();
			this.ui.find('.btn_close').show();
		}
		else {
			this.ui.find('.buttons').hide();
			this.ui.find('.btn_open').show();
			this.ui.find('.btn_close').hide();
		}

		this.ui.find('#battle').hide();
		this.ui.find('#navigation').hide();
<<<<<<< HEAD
		this.ui.find('#battle').hide();
=======
		this.ui.find('#battle').hide(); // >>>> Sao lại có 2 dòng như nhau
>>>>>>> 37b81d87e (init robrowser)
		this.ui.find('#replay').hide();
		this.ui.find('#achievment').hide();
		this.ui.find('#tipbox').hide();
		this.ui.find('#shortcut').hide();
		this.ui.find('#agency').hide();
	};


	/**
	 * Once remove, save preferences
	 */
<<<<<<< HEAD
	BasicInfoV5.onRemove = function onRemove()
	{
		_preferences.x       = parseInt(this.ui.css('left'), 10);
		_preferences.y       = parseInt(this.ui.css('top'), 10);
		_preferences.reduce  = this.ui.hasClass('small');
=======
	BasicInfoV5.onRemove = function onRemove() {
		_preferences.x = parseInt(this.ui.css('left'), 10);
		_preferences.y = parseInt(this.ui.css('top'), 10);
		_preferences.reduce = this.ui.hasClass('small');
>>>>>>> 37b81d87e (init robrowser)
		_preferences.buttons = this.ui.find('.buttons').is(':visible');
		_preferences.magnet_top = this.magnet.TOP;
		_preferences.magnet_bottom = this.magnet.BOTTOM;
		_preferences.magnet_left = this.magnet.LEFT;
		_preferences.magnet_right = this.magnet.RIGHT;
		_preferences.save();
	};


	/**
	 * Process shortcut
	 *
	 * @param {object} key
	 */
<<<<<<< HEAD
	BasicInfoV5.onShortCut = function onShortCut( key )
	{
=======
	BasicInfoV5.onShortCut = function onShortCut(key) {
>>>>>>> 37b81d87e (init robrowser)
		switch (key.cmd) {
			case 'EXTEND':
				this.toggleMode();
				break;
		}
	};


	/**
	 * Switch window size
	 */
<<<<<<< HEAD
	BasicInfoV5.toggleMode = function toggleMode()
	{
=======
	BasicInfoV5.toggleMode = function toggleMode() {
>>>>>>> 37b81d87e (init robrowser)
		var type;

		this.ui.toggleClass('small large');

		if (_preferences.buttons) {
			this.ui.find('.buttons').show();
			this.ui.find('#btn_open').hide();
			this.ui.find('.btn_close').show();
		}
		else {
			this.ui.find('.buttons').hide();
			this.ui.find('.btn_open').show();
			this.ui.find('.btn_close').hide();
		}
	};


	/**
	 * Toggle the list of buttons
	 */
<<<<<<< HEAD
	BasicInfoV5.toggleButtons = function toggleButtons( event )
	{
=======
	BasicInfoV5.toggleButtons = function toggleButtons(event) {
>>>>>>> 37b81d87e (init robrowser)
		var type;
		var $buttons = this.ui.find('.buttons');

		_preferences.buttons = !$buttons.is(':visible');

		if (_preferences.buttons) {
			this.ui.find('.buttons').show();
			this.ui.find('#btn_open').hide();
			this.ui.find('.btn_close').show();
		}
		else {
			this.ui.find('.buttons').hide();
			this.ui.find('.btn_open').show();
			this.ui.find('.btn_close').hide();
		}

		event.stopImmediatePropagation();
	};


	/**
	 * Update UI elements
	 *
	 * @param {string} type identifier
	 * @param {number} val1
	 * @param {number} val2 (optional)
	 */
<<<<<<< HEAD
	BasicInfoV5.update = function update( type, val1, val2 )
	{
=======
	BasicInfoV5.update = function update(type, val1, val2) {
>>>>>>> 37b81d87e (init robrowser)
		switch (type) {
			case 'name':
			case 'blvl':
			case 'jlvl':
<<<<<<< HEAD
				this.ui.find('.'+ type +'_value').text(val1);
=======
				this.ui.find('.' + type + '_value').text(val1);
>>>>>>> 37b81d87e (init robrowser)
				break;

			case 'zeny':
				Session.zeny = val1;

				var list = val1.toString().split('');
				var i, count = list.length;
				var str = '';

				for (i = 0; i < count; i++) {
<<<<<<< HEAD
					str = list[count-i-1] + (i && i%3 ===0 ? ',' : '') + str;
				}

				this.ui.find('.'+ type +'_value').text(str);
=======
					str = list[count - i - 1] + (i && i % 3 === 0 ? ',' : '') + str;
				}

				this.ui.find('.' + type + '_value').text(str);
>>>>>>> 37b81d87e (init robrowser)
				break;

			case 'job':
				Session.Character.job = val1;

				this.ui.find('.job_value').text(MonsterTable[val1]);
				break;

			case 'bexp':
			case 'jexp':
				if (!val2) {
					this.ui.find('.' + type).hide();
					break;
				}

<<<<<<< HEAD
				this.ui.find('.'+ type).show();
				this.ui.find('.'+ type +' div').css('width', Math.min( 100, Math.floor(val1 * 100 / val2) ) + '%');
				this.ui.find('.'+ type).attr('title', ((val1/val2)*100).toFixed(1) + '%');
				this.ui.find('.'+ type +'_value').text( Math.min( 100, (Math.floor(val1 * 1000 / val2) * 0.1).toFixed(1)) + '%');
=======
				this.ui.find('.' + type).show();
				this.ui.find('.' + type + ' div').css('width', Math.min(100, Math.floor(val1 * 100 / val2)) + '%');
				this.ui.find('.' + type).attr('title', ((val1 / val2) * 100).toFixed(1) + '%');
				this.ui.find('.' + type + '_value').text(Math.min(100, (Math.floor(val1 * 1000 / val2) * 0.1).toFixed(1)) + '%');
>>>>>>> 37b81d87e (init robrowser)
				break;

			case 'weight':
				this.ui.find('.weight_value').text(val1 / 10 | 0);
				this.ui.find('.weight_total').text(val2 / 10 | 0);
<<<<<<< HEAD
				this.ui.find('.weight').css('color',  val1 < (val2/2) ? '' : 'red');
				this.ui.find('.weight').attr('title', ((val1/val2)*100).toFixed(1) + '%');
=======
				this.ui.find('.weight').css('color', val1 < (val2 / 2) ? '' : 'red');
				this.ui.find('.weight').attr('title', ((val1 / val2) * 100).toFixed(1) + '%');
>>>>>>> 37b81d87e (init robrowser)
				break;

			case 'hp':
			case 'sp':
<<<<<<< HEAD
				var perc  = Math.floor(val1 * 100 / val2);
				var color = perc < 25 ? 'red' : 'blue';
				this.ui.find('.'+ type +'_value').text(val1);
				this.ui.find('.'+ type +'_max_value').text(val2);
				this.ui.find('.'+ type +'_perc').text( perc + '%');

				if (perc <= 0) {
					this.ui.find('.'+ type +'_bar div').css('backgroundImage', 'none');
					break;
				}

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_left.bmp', function(url){
					this.ui.find('.'+ type +'_bar_left').css('backgroundImage', 'url('+ url +')');
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_mid.bmp', function(url){
					this.ui.find('.'+ type +'_bar_middle').css({
						backgroundImage: 'url('+ url +')',
						width: Math.floor( Math.min( perc, 100 ) * 1.27 ) + 'px'
					});
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_right.bmp', function(url){
					this.ui.find('.'+ type +'_bar_right').css({
						backgroundImage: 'url('+ url +')',
						left: Math.floor( Math.min( perc, 100) * 1.27 ) + 'px'
					});
				}.bind(this));
				break;
			
			case 'ap':
				var perc  = Math.floor(val1 * 100 / val2);
				var color = perc === 100 ? 'red' : 'blue';
				this.ui.find('.'+ type +'_value').text(val1);
				this.ui.find('.'+ type +'_max_value').text(val2);
				this.ui.find('.'+ type +'_perc').text( perc + '%');
				if (perc <= 0) {
					this.ui.find('.'+ type +'_bar div').css('backgroundImage', 'none');
					break;
				}

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_left.bmp', function(url){
					this.ui.find('.'+ type +'_bar_left').css('backgroundImage', 'url('+ url +')');
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_mid.bmp', function(url){
					this.ui.find('.'+ type +'_bar_middle').css({
						backgroundImage: 'url('+ url +')',
						width: Math.floor( Math.min( perc, 100 ) * 1.27 ) + 'px'
					});
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze'+ color +'_right.bmp', function(url){
					this.ui.find('.'+ type +'_bar_right').css({
						backgroundImage: 'url('+ url +')',
						left: Math.floor( Math.min( perc, 100) * 1.27 ) + 'px'
=======
				var perc = Math.floor(val1 * 100 / val2);
				var color = perc < 25 ? 'red' : 'blue';
				this.ui.find('.' + type + '_value').text(val1);
				this.ui.find('.' + type + '_max_value').text(val2);
				this.ui.find('.' + type + '_perc').text(perc + '%');

				if (perc <= 0) {
					this.ui.find('.' + type + '_bar div').css('backgroundImage', 'none');
					break;
				}

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_left.bmp', function (url) {
					this.ui.find('.' + type + '_bar_left').css('backgroundImage', 'url(' + url + ')');
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_mid.bmp', function (url) {
					this.ui.find('.' + type + '_bar_middle').css({
						backgroundImage: 'url(' + url + ')',
						width: Math.floor(Math.min(perc, 100) * 1.27) + 'px'
					});
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_right.bmp', function (url) {
					this.ui.find('.' + type + '_bar_right').css({
						backgroundImage: 'url(' + url + ')',
						left: Math.floor(Math.min(perc, 100) * 1.27) + 'px'
					});
				}.bind(this));
				break;

			case 'ap':
				var perc = Math.floor(val1 * 100 / val2);
				var color = perc === 100 ? 'red' : 'blue';
				this.ui.find('.' + type + '_value').text(val1);
				this.ui.find('.' + type + '_max_value').text(val2);
				this.ui.find('.' + type + '_perc').text(perc + '%');
				if (perc <= 0) {
					this.ui.find('.' + type + '_bar div').css('backgroundImage', 'none');
					break;
				}

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_left.bmp', function (url) {
					this.ui.find('.' + type + '_bar_left').css('backgroundImage', 'url(' + url + ')');
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_mid.bmp', function (url) {
					this.ui.find('.' + type + '_bar_middle').css({
						backgroundImage: 'url(' + url + ')',
						width: Math.floor(Math.min(perc, 100) * 1.27) + 'px'
					});
				}.bind(this));

				Client.loadFile(DB.INTERFACE_PATH + 'basic_interface/gze' + color + '_right.bmp', function (url) {
					this.ui.find('.' + type + '_bar_right').css({
						backgroundImage: 'url(' + url + ')',
						left: Math.floor(Math.min(perc, 100) * 1.27) + 'px'
>>>>>>> 37b81d87e (init robrowser)
					});
				}.bind(this));
				break;
		}
	};


	/**
	 * Create component and export it
	 */
	return UIManager.addComponent(BasicInfoV5);
});
