/**
 * UI/Components/BarterExpShop/BarterExpShop.js
 *
 * Chararacter Basic information windows
 *
 * This file is part of ROBrowser, (http://www.robrowser.com/).
 *
 * @author Vincent Thibault
 */
define(function (require) {
	'use strict';


	/**
	 * Dependencies
	 */
	var jQuery = require('Utils/jquery');
	var DB = require('DB/DBManager');
	var ItemType = require('DB/Items/ItemType');
	var Client = require('Core/Client');
	var Preferences = require('Core/Preferences');
	var Session = require('Engine/SessionStorage');
	var Mouse = require('Controls/MouseEventHandler');
	var Network = require('Network/NetworkManager');
	var PACKETVER = require('Network/PacketVerManager');
	var PACKET = require('Network/PacketStructure');
	var KEYS = require('Controls/KeyEventHandler');
	var UIManager = require('UI/UIManager');
	var UIComponent = require('UI/UIComponent');
	var ItemInfo = require('UI/Components/ItemInfo/ItemInfo');
	var InputBox = require('UI/Components/InputBox/InputBox');
	var ChatBox = require('UI/Components/ChatBox/ChatBox');
	var Inventory = require('UI/Components/Inventory/Inventory');
	var htmlText = require('text!./BarterExpShop.html');
	var cssText = require('text!./BarterExpShop.css');


	/**
	 * Create NPC Menu component
	 */
	var BarterExpShop = new UIComponent('BarterExpShop', htmlText, cssText);

	/**
	 * Freeze the mouse
	 */
	BarterExpShop.mouseMode = UIComponent.MouseMode.FREEZE;

	/**
	 * @var {Preferences}
	 */
	var _preferences = Preferences.get('BarterExpShop', {
		inputWindow: {
			x: 100,
			y: 100,
			height: 7
		},
		outputWindow: {
			x: 100 + 280 + 10,
			y: 100 + (7 * 32) - (2 * 32),
			height: 2
		}
	}, 1.0);


	/**
	 * @var {Array} item list
	 */
	var _input = [];


	/**
	 * @var {Array} output list
	 */
	var _output = [];

	/**
	 * Initialize component
	 */
	BarterExpShop.init = function init() {
		var ui = this.ui;
		var InputWindow = ui.find('.InputWindow');
		var OutputWindow = ui.find('.OutputWindow');

		ui.find('.btn.cancel').click(function () {
			BarterExpShop.remove();
			var pkt = new PACKET.CZ.NPC_EXPANDED_BARTER_MARKET_CLOSE();
			Network.sendPacket(pkt);
		});

		// Client do not send packet
		ui.find('.btn.buy').click(this.submit.bind(this));

		// Resize
		InputWindow.find('.resize').mousedown(function () { onResize(InputWindow); });
		OutputWindow.find('.resize').mousedown(function () { onResize(OutputWindow); });

		// Items options
		ui.find('.content')
			.on('mousewheel DOMMouseScroll', onScroll)
			.on('contextmenu', '.icon', onItemInfo)
			.on('contextmenu', '.itemPrice', onItemInfo)
			.on('dblclick', '.item', onItemSelected)
			.on('mousedown', '.item', onItemFocus)
			.on('dragstart', '.item', onDragStart)
			.on('dragend', '.item', function () {
				delete window._OBJ_DRAG_;
			});

		// Drop items
		ui.find('.InputWindow, .OutputWindow')
			.on('drop', onDrop)
			.on('dragover', function (event) {
				event.stopImmediatePropagation();
				return false;
			})
			.on('mousedown', function () {
				BarterExpShop.focus();
			});

		// Hacky drag drop
		this.draggable.call({ ui: InputWindow }, InputWindow.find('.titlebar'));
		this.draggable.call({ ui: OutputWindow }, OutputWindow.find('.titlebar'));
	};


	/**
	 * Player should not be able to move when the store is opened
	 */
	BarterExpShop.onAppend = function onAppend() {
		var InputWindow = this.ui.find('.InputWindow');
		var OutputWindow = this.ui.find('.OutputWindow');

		InputWindow.css({ top: _preferences.inputWindow.y, left: _preferences.inputWindow.x });
		OutputWindow.css({ top: _preferences.outputWindow.y, left: _preferences.outputWindow.x });

		resize(InputWindow.find('.content'), _preferences.inputWindow.height);
		resize(OutputWindow.find('.content'), _preferences.outputWindow.height);

		// Seems like "EscapeWindow" is execute first, push it before.
		var events = jQuery._data(window, 'events').keydown;
		events.unshift(events.pop());
	};


	/**
	 * Released movement and save preferences
	 */
	BarterExpShop.onRemove = function onRemove() {
		var InputWindow = this.ui.find('.InputWindow');
		var OutputWindow = this.ui.find('.OutputWindow');

		_input.length = 0;
		_output.length = 0;

		_preferences.inputWindow.x = parseInt(InputWindow.css('left'), 10);
		_preferences.inputWindow.y = parseInt(InputWindow.css('top'), 10);
		_preferences.inputWindow.height = InputWindow.find('.content').height() / 32 | 0;

		_preferences.outputWindow.x = parseInt(OutputWindow.css('left'), 10);
		_preferences.outputWindow.y = parseInt(OutputWindow.css('top'), 10);
		_preferences.outputWindow.height = OutputWindow.find('.content').height() / 32 | 0;

		_preferences.save();

		this.ui.find('.content').empty();
		this.ui.find('.total .result').text(0);


	};


	/**
	 * Key Listener
	 *
	 * Remove the UI when Escape key is pressed
	 */
	BarterExpShop.onKeyDown = function onKeyDown(event) {
		if (event.which === KEYS.ESCAPE) {
			this.remove();
			event.stopImmediatePropagation();

			if (PACKETVER.value >= 20131223) {
				var pkt = new PACKET.CZ.NPC_EXPANDED_BARTER_MARKET_CLOSE();
				Network.sendPacket(pkt);
			}

			return false;
		}

		return true;
	};

	/**
	 * Add items to list
	 *
	 * @param {Array} item list
	 */
	BarterExpShop.setList = function setList(items) {
		var i, count;
		var it, item, out, content;

		this.ui.find('.content').empty();
		this.ui.find('.total .result').text(0);

		_input.length = 0;
		_output.length = 0;
		content = this.ui.find('.InputWindow .content');
		for (i = 0, count = items.length; i < count; ++i) {
			if (!('index' in items[i])) {
				items[i].index = i;
			}
			items[i].count = items[i].qty >= 1 ? items[i].qty : Infinity;
			items[i].IsIdentified = true;
			out = jQuery.extend({}, items[i]);
			out.count = 0;
			addItem(content, items[i]);

			_input[items[i].index] = items[i];
			_output[items[i].index] = out;
		}
	};

	/**
	 * Submit data to send items
	 */
	BarterExpShop.submit = function submit() {
		var output;
		var i, count;

		output = [];
		count = _output.length;

		for (i = 0; i < count; ++i) {
			if (_output[i] && _output[i].count) {
				output.push(_output[i]);
			}
		}

		BarterExpShop.onSubmit(output);
	};


	/**
	 * Calculate the cost of all items in the output box
	 *
	 * @return {number}
	 */
	BarterExpShop.calculateCost = function calculateCost() {
		var i, count, total;

		total = 0;
		count = _output.length;

		for (i = 0; i < count; ++i) {
			if (_output[i]) {
				total += (_output[i].price || 0) * _output[i].count;
			}
		}

		this.ui.find('.total .result').text(prettyZeny(total));

		return total;
	};


	/**
	 * Prettify zeny : 1000000 -> 1,000,000
	 *
	 * @param {number} zeny
	 * @param {boolean} use color
	 * @return {string}
	 */
	function prettyZeny(val, useStyle) {
		var list = val.toString().split('');
		var i, count = list.length;
		var str = '';

		for (i = 0; i < count; i++) {
			str = list[count - i - 1] + (i && i % 3 === 0 ? ',' : '') + str;
		}

		if (useStyle) {
			var style = [
				'color:#000000; text-shadow:1px 0px #00ffff;', // 0 - 9
				'color:#0000ff; text-shadow:1px 0px #ce00ce;', // 10 - 99
				'color:#0000ff; text-shadow:1px 0px #00ffff;', // 100 - 999
				'color:#ff0000; text-shadow:1px 0px #ffff00;', // 1,000 - 9,999
				'color:#ff18ff;',                              // 10,000 - 99,999
				'color:#0000ff;',                              // 100,000 - 999,999
				'color:#000000; text-shadow:1px 0px #00ff00;', // 1,000,000 - 9,999,999
				'color:#ff0000;',                              // 10,000,000 - 99,999,999
				'color:#000000; text-shadow:1px 0px #cece63;', // 100,000,000 - 999,999,999
				'color:#ff0000; text-shadow:1px 0px #ff007b;', // 1,000,000,000 - 9,999,999,999
			];
			str = '<span style="' + style[count - 1] + '">' + str + '</span>';
		}

		return str;
	}


	/**
	 * Add item to the list
	 *
	 * @param {jQuery} content element
	 * @param {Item} item info
	 */
	function addItem(content, item) {

		var it = DB.getItemInfo(item.nameid);
		var itPrice = DB.getItemInfo(item.currencyNameid);
		var element = content.find('.item[data-index=' + item.index + ']:first');
		var priceAmount;
		let amountText;

		// 0 as amount ? remove it
		if (item.count === 0) {
			if (element.length) {
				element.remove();
			}
			return;
		}

		// Already here, update it
		// Note: just the amount can be updated ?

		if (element.length) {
			amountText = '';
			element.find('.amount').text(isFinite(item.count) ? item.count + amountText : '');
			return;
		}


		if (!(content.hasClass('contentAvailable'))) {
			priceAmount = prettyZeny(item.zeny);

			// Create it
			let html = '<div class="item" draggable="true" data-index="' + item.index + '">' +
				'<div class="icon"></div>' +
				'<div class="amount">' + (isFinite(item.count) ? item.count : '') + '</div>' +
				'<div class="name">' + jQuery.escape(it.identifiedDisplayName) + '</div>' +
				'<div class="price">' +
				'<div class="priceItem"></div>' +
				'<div class="priceAmount">' + priceAmount + ' Z</div>' +
				'</div>' +
				'</div>';
			if (item.currencies.length > 0) {
				html += '<div class="item rowCurrencies" data-index="' + item.index + '">'
				for (let c = 0; c < item.currencies.length; c++) {
					html += '<div class="currencyBlock">'
					html += '<div class="itemC" data-itemid="' + item.currencies[c].nameid + '">'
					html += '<div class="itemA">' + prettyZeny(item.currencies[c].amount) + '</div>'
					if (parseInt(item.currencies[c].refine_level) > 0)
						html += '<div class="itemR">+' + item.currencies[c].refine_level + '</div>'
					html += '</div>'
					html += '</div>'
				}
				html += '</div>'
			}
			content.append(html);
		} else {
			content.append(
				'<div class="item itemAvailable" draggable="true" data-index="' + item.index + '">' +
				'<div class="icon"></div>' +
				'<div class="amount">' + (isFinite(item.count) ? item.count : '') + '</div>' +
				'<div class="nameOverlay">' + jQuery.escape(it.identifiedDisplayName) + '</div>' +
				'</div>'
			);
		}
		// Add the icon once loaded
		let arrItemC = content.find(".rowCurrencies[data-index='" + item.index + "'] .itemC");
		for (let c = 0; c < arrItemC.length; c++) {
			//console.log(jQuery(arrItemC[c]).attr('data-itemid'));
			let itC = DB.getItemInfo(jQuery(arrItemC[c]).attr('data-itemid'));
			console.log(itC);
			Client.loadFile(DB.INTERFACE_PATH + 'item/' + itC.identifiedResourceName + '.bmp', function (dataC) {
				console.log("Load image:", jQuery(arrItemC[c]).attr('data-itemid'));
				content.find(".itemC[data-itemid='" + jQuery(arrItemC[c]).attr('data-itemid') + "']").css('backgroundImage', 'url(' + dataC + ')');
			});
		}
		Client.loadFile(DB.INTERFACE_PATH + 'item/' + it.identifiedResourceName + '.bmp', function (data) {
			content.find('.item[data-index="' + item.index + '"] .icon').css('backgroundImage', 'url(' + data + ')');
		});
	}


	/**
	 * Resize the content
	 *
	 * @param {jQueryElement} content
	 * @param {number} height
	 */
	function resize(content, height) {
		height = Math.min(Math.max(height, 2), 9);
		content.css('height', height * 32);
	}


	/**
	 * Resizing window
	 *
	 * @param {jQueryElement} ui element
	 */
	function onResize(ui) {
		var top = ui.position().top;
		var content = ui.find('.content:first');
		var lastHeight = 0;
		var interval;

		function resizing() {
			var extraY = 31 + 19 - 30;
			var h = Math.floor((Mouse.screen.y - top - extraY) / 32);

			// Maximum and minimum window size
			h = Math.min(Math.max(h, 2), 9);
			if (h === lastHeight) {
				return;
			}

			resize(content, h);
			lastHeight = h;
		}

		// Start resizing
		interval = setInterval(resizing, 30);

		// Stop resizing on left click
		jQuery(window).on('mouseup.resize', function (event) {
			if (event.which === 1) {
				clearInterval(interval);
				jQuery(window).off('mouseup.resize');
			}
		});
	}


	/**
	 * Transfer item from input to output (or the inverse)
	 *
	 * @param {jQueryElement} from content (input / output)
	 * @param {jQueryElement} to content (input / output)
	 * @param {boolean} is adding the content to the output element
	 * @param {number} item index
	 * @param {number} amount
	 */
	var transferItem = function transferItemQuantityClosure() {
		var tmpItem = {
			ITID: 0,
			count: 0,
			price: 0,
			index: 0
		};

		return function transferItem(fromContent, toContent, isAdding, index, count) {
			// Add item to the list
			if (isAdding) {

				// You don't have enough zeny
				if (BarterExpShop.calculateCost() + (_input[index].discountprice || _input[index].price) * count > Session.zeny) {
					ChatBox.addText(DB.getMessage(55), ChatBox.TYPE.ERROR, ChatBox.FILTER.PUBLIC_LOG);
					return;
				}

				_output[index].count = Math.min(_output[index].count + count, _input[index].count);

				// Update input ui item amount
				tmpItem.ITID = _input[index].ITID;
				tmpItem.count = _input[index].count - _output[index].count;
				tmpItem.price = _input[index].price;
				tmpItem.index = _input[index].index;

				addItem(fromContent, tmpItem);
				addItem(toContent, _output[index]);

				if (typeof _output[index].maxCount !== 'undefined' && _output[index].count > _output[index].maxCount) {
					let text = DB.getMessage(1739);
					let result = text.replace("%d", _output[index].maxCount); // workaround
					ChatBox.addText(result, ChatBox.TYPE.ERROR, ChatBox.FILTER.PUBLIC_LOG);
				}
			}

			// Remove item
			else {
				count = Math.min(count, _output[index].count);
				if (!count) {
					return;
				}

				_output[index].count -= count;

				// Update input ui item amount
				tmpItem.ITID = _input[index].ITID;
				tmpItem.count = _input[index].count + _output[index].count;
				tmpItem.price = _input[index].price;
				tmpItem.index = _input[index].index;

				addItem(fromContent, _output[index]);
				addItem(toContent, tmpItem);
			}

			BarterExpShop.calculateCost();
		};
	}();


	/**
	 * Request move item from box to another
	 *
	 * @param {number} item index
	 * @param {jQueryElement} from the content
	 * @param {jQueryElement} to the content
	 * @param {boolean} add the content to the output box ?
	 */
	function requestMoveItem(index, fromContent, toContent, isAdding) {
		var item, count;
		var isStackable;

		item = isAdding ? _input[index] : _output[index];
		isStackable = (
			item.type !== ItemType.WEAPON &&
			item.type !== ItemType.EQUIP &&
			item.type !== ItemType.PETEGG &&
			item.type !== ItemType.PETEQUIP
		);

		if (isAdding) {
			count = isFinite(_input[index].count) ? _input[index].count : 1;
		}
		else {
			count = _output[index].count;
		}

		/*
		// Can't buy more than one same stackable item
		if ((_type === BarterExpShop.Type.BUY || _type === BarterExpShop.Type.VENDING_STORE) && !isStackable && isAdding) {
			if (toContent.find('.item[data-index="' + item.index + '"]:first').length) {
				return false;
			}
		}
		*/

		// Just one item amount
		if (item.count === 1 || !isStackable) {
			transferItem(fromContent, toContent, isAdding, index, isFinite(item.count) ? item.count : 1);
			return false;
		}

		// Have to specify an amount
		InputBox.append();
		InputBox.setType('number', false, count);
		InputBox.onSubmitRequest = function (count) {
			InputBox.remove();
			if (count > 0) {
				transferItem(fromContent, toContent, isAdding, index, count);
			}
		};
	}


	/**
	 * Drop an input in the InputWindow or OutputWindow
	 *
	 * @param {jQueryEvent} event
	 */
	function onDrop(event) {
		var data;

		event.stopImmediatePropagation();

		try {
			data = JSON.parse(event.originalEvent.dataTransfer.getData('Text'));
		}
		catch (e) {
			return false;
		}

		// Just allow item from store
		if (data.type !== 'item' || data.from !== 'BarterExpShop' || data.container === this.className) {
			return false;
		}

		requestMoveItem(
			data.index,
			jQuery('.' + data.container + ' .content'),
			jQuery(this).find('.content'),
			this.className === 'OutputWindow'
		);

		return false;
	}


	/**
	 * Get informations about an item
	 */
	function onItemInfo(event) {
		var index = parseInt(this.parentNode.getAttribute('data-index'), 10);
		var item = _input[index];

		event.stopImmediatePropagation();

		if (!item) {
			return false;
		}

		// Don't add the same UI twice, remove it
		if (ItemInfo.uid === item.ITID) {
			ItemInfo.remove();
			return false;
		}

		// Add ui to window
		ItemInfo.append();
		ItemInfo.uid = item.ITID;
		ItemInfo.setItem(item);
		return false;
	}


	/**
	 * Select an item, put it on the other box
	 */
	function onItemSelected() {
		var input, from, to;

		/*
		if ((_type === BarterExpShop.Type.BUY || _type === BarterExpShop.Type.VENDING_STORE) && !Session.isTouchDevice) {
			return;
		}
		*/

		input = BarterExpShop.ui.find('.InputWindow:first');

		if (jQuery.contains(input.get(0), this)) {
			from = input;
			to = BarterExpShop.ui.find('.OutputWindow:first');
		}
		else {
			from = BarterExpShop.ui.find('.OutputWindow:first');
			to = input;
		}

		requestMoveItem(
			parseInt(this.getAttribute('data-index'), 10),
			from.find('.content:first'),
			to.find('.content:first'),
			from === input
		);
	}


	/**
	 * Focus an item
	 */
	function onItemFocus() {
		BarterExpShop.ui.find('.item.selected').removeClass('selected');
		BarterExpShop.ui.find('.item.rowCurrencies.selected').removeClass('selected');
		jQuery(this).addClass('selected');
		BarterExpShop.ui.find('.item.rowCurrencies[data-index="' + jQuery(this).attr('data-index') + '"]').removeClass('selected');

	}


	/**
	 * Update scroll by block (32px)
	 */
	function onScroll(event) {
		var delta;

		if (event.originalEvent.wheelDelta) {
			delta = event.originalEvent.wheelDelta / 120;
			if (window.opera) {
				delta = -delta;
			}
		}
		else if (event.originalEvent.detail) {
			delta = -event.originalEvent.detail;
		}

		this.scrollTop = Math.floor(this.scrollTop / 32) * 32 - (delta * 32);
		return false;
	}


	/**
	 * Start dragging an item
	 */
	function onDragStart(event) {
		var container, img, url;
		var InputWindow, OutputWindow, AvailableItemsWindow;

		InputWindow = BarterExpShop.ui.find('.InputWindow:first').get(0);
		OutputWindow = BarterExpShop.ui.find('.OutputWindow:first').get(0);

		container = (jQuery.contains(InputWindow, this) ? InputWindow : OutputWindow).className;
		img = new Image();
		url = this.firstChild.style.backgroundImage.match(/\(([^\)]+)/)[1].replace(/"/g, '');
		img.src = url;

		event.originalEvent.dataTransfer.setDragImage(img, 12, 12);
		event.originalEvent.dataTransfer.setData('Text',
			JSON.stringify(window._OBJ_DRAG_ = {
				type: 'item',
				from: 'BarterExpShop',
				container: container,
				index: this.getAttribute('data-index')
			})
		);
	}

	/**
	 * Exports
	 */
	BarterExpShop.onSubmit = function onSubmit(output) {
		var pkt = new PACKET.CZ.NPC_EXPANDED_BARTER_MARKET_PURCHASE();
		pkt.list = [];
		for (let i = 0; i < output.length; i++) {
			pkt.list.push({
				itemId: output[i].nameid,
				amount: output[i].count,
				shopIndex: output[i].index
			});
		}
		Network.sendPacket(pkt);
	};


	/**
	 * Create componentand export it
	 */
	return UIManager.addComponent(BarterExpShop);
});
