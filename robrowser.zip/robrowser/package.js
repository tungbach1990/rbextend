{
	"name": "roBrowser",
	"main": "applications/node-webkit/window.html",
 	"window": {
		"title": "rAthena",
	
		"width":  1024,
		"height":  768,
	
		"min_width": 1024,
		"max_width": 1024,
	
		"min_height": 768,
		"max_height": 768,
	
		"fullscreen": false,
		"frame":      true,
		"icon":       "applications/icon_128.png",
		"toolbar":    true
	},
	"chromium-args": "--enable-webgl --ignore-gpu-blacklist"
}
